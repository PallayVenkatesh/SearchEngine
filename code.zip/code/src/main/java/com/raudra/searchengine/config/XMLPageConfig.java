package com.raudra.searchengine.config;

/**
 * Created by satheeesh on 22/11/16.
 */
public class XMLPageConfig {
    public static final String ELEMENT_TITLE = "title";
    public static final String ELEMENT_ID = "id";
    public static final String ELEMENT_TEXT = "text";
}
